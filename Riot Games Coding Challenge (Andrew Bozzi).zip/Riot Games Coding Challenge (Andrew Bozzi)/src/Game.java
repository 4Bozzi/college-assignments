/**
 * @author Andrew Bozzi
 * Riot Games Code Sample
 * 5/10/10
 */

import junit.framework.TestCase;

//The game class is the driver that sets up the data followed by the jUnit tests.
//The primary set of functions are tested as well as some tests on the nature of the data structures.
//The getters and setters were not tested or commented due to them being more trivial.
public class Game extends TestCase {
	Player player1, player2;
	
	//Constants to make the code a little bit more readable
	int assistsID = 0;
	int firstHitKillsID = 1;
	int hitsID = 2;
	int killsID = 3;
	int attacksID = 4;
	int spellDamageID = 5;
	int spellsCastID = 6;
	int timePlayedID = 7;
	int damageDealtID = 8;
	int gamesWonID = 9;
	int gamesPlayedID = 10;
	int percentHitsID = 11;
	int buildingsDestroyedID = 12;

	public void testStats() {
		System.out.println("The Game has Ended!");
		
		//Create players, only 2 for the sake of demonstrating functionality
		player1 = new Player("Kassadin");
		player2 = new Player("Jax");
		
		//Set up player1's achievements
		player1.getAchievementsList().add(new Award_BigWinner());
		player1.getAchievementsList().add(new Award_Bruiser());
		player1.getAchievementsList().add(new Award_SharpShooter());
		player1.getAchievementsList().add(new Award_Veteran());
		player1.getAchievementsList().add(new Award_WreckingBall());
		
		//Set up player2's achievements
		player2.getAchievementsList().add(new Award_BigWinner());
		player2.getAchievementsList().add(new Award_Bruiser());
		player2.getAchievementsList().add(new Award_SharpShooter());
		player2.getAchievementsList().add(new Award_Veteran());
		player2.getAchievementsList().add(new Award_WreckingBall());
		
		//Set up player1's statistics hash map with data as if a game just ended.
		//for the same of this code sample I did not think there was a need to differentiate between game stats 
		//and historical, they both  have the same functionality.
		player1.getStatsList().put(assistsID, new Statistic_Assists(10));
		player1.getStatsList().put(firstHitKillsID, new Statistic_FirstHitKills(10));
		player1.getStatsList().put(hitsID, new Statistic_Hits(74));
		player1.getStatsList().put(killsID, new Statistic_Kills(10));
		player1.getStatsList().put(attacksID, new Statistic_NumOfAttacks(100));
		player1.getStatsList().put(spellDamageID, new Statistic_SpellDamageDealt(10));
		player1.getStatsList().put(spellsCastID, new Statistic_SpellsCast(10));
		player1.getStatsList().put(timePlayedID, new Statistic_TimePlayed(55));
		player1.getStatsList().put(damageDealtID, new Statistic_TotalDamageDealt(734));
		player1.getStatsList().put(gamesWonID, new Statistic_GamesWon(199));
		player1.getStatsList().put(gamesPlayedID, new Statistic_GamesPlayed(1000));
		player1.getStatsList().put(percentHitsID, new Statistic_PercentHit(74));
		player1.getStatsList().put(buildingsDestroyedID, new Statistic_BuildingsDestroyed(2));
		
		
		//Set up player1's statistics List
		player2.getStatsList().put(assistsID, new Statistic_Assists(5));
		player2.getStatsList().put(firstHitKillsID, new Statistic_FirstHitKills(0));
		player2.getStatsList().put(hitsID, new Statistic_Hits(51));
		player2.getStatsList().put(killsID, new Statistic_Kills(9));
		player2.getStatsList().put(attacksID, new Statistic_NumOfAttacks(100));
		player2.getStatsList().put(spellDamageID, new Statistic_SpellDamageDealt(5));
		player2.getStatsList().put(spellsCastID, new Statistic_SpellsCast(5));
		player2.getStatsList().put(timePlayedID, new Statistic_TimePlayed(55));
		player2.getStatsList().put(damageDealtID, new Statistic_TotalDamageDealt(499));
		player2.getStatsList().put(gamesWonID, new Statistic_GamesWon(201));
		player2.getStatsList().put(gamesPlayedID, new Statistic_GamesPlayed(958));
		player2.getStatsList().put(percentHitsID, new Statistic_PercentHit(51));
		player2.getStatsList().put(buildingsDestroyedID, new Statistic_BuildingsDestroyed(3));
		
		//Test cases
		//test that the statistic ID is right no matter what player has the stat.
		assertEquals(player1.getStatsList().get(damageDealtID).getStatisticID(), player2.getStatsList().get(damageDealtID).getStatisticID());
		
		//check that player1 and player 2 do not share the same statistic hash map object
		assertNotSame(player1.getStatsList(), player2.getStatsList());
		
		//check that the different statistics have different ID numbers.
		assertNotSame(player1.getStatsList().get(damageDealtID).getStatisticID(), player1.getStatsList().get(timePlayedID).getStatisticID());
		
		//at this point player1 and player2 should have no earned achievements
		assertEquals(player1.getEarnedAchievementsList().size(), 0);
		
		//double check that the values for Damage Dealt are correct for the different users
		assertEquals(player1.getStatsList().get(damageDealtID).getStatisticValue(), 734);
		assertEquals(player2.getStatsList().get(damageDealtID).getStatisticValue(), 499);
		
		//Run the check on all players in the game
		player1.checkForNewAchievements();
		player2.checkForNewAchievements();
		
		//check that the size of earned achievements went up and unearned went down by the right amounts
		assertEquals(player1.getEarnedAchievementsList().size(), 2);
		assertEquals(player2.getEarnedAchievementsList().size(), 2);
		assertEquals(player1.getAchievementsList().size(), 3);
		assertEquals(player2.getAchievementsList().size(), 3);
		
	}
}
