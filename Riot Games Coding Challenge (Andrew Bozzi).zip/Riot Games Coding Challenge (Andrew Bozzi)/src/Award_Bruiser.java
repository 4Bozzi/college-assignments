/**
 * @author Andrew Bozzi
 * Riot Games Code Sample
 * 5/10/10
 */

//This achievement uses the default checkIfEarned method from achievement.
public class Award_Bruiser extends Achievement{
	public Award_Bruiser(){
		this.description = "A user receives this achievement for doing more than 500 points of damage in one game.";
		this.name = "Bruiser";
		this.stat = new Statistic_TotalDamageDealt();
		this.targetValue = 500;
	}
}
