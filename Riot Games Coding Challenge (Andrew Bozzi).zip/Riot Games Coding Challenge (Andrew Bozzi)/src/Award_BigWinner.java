/**
 * @author Andrew Bozzi
 * Riot Games Code Sample
 * 5/10/10
 */

//This achievement uses the default checkIfEarned method from achievement.
public class Award_BigWinner extends Achievement{
	public Award_BigWinner(){
		this.description = "A user receives this achievement for winning 200 games in their lifetime.";
		this.name = "Big Winner";
		this.stat = new Statistic_GamesWon();
		this.targetValue = 200;
	}
}
