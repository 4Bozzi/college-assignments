/**
 * @author Andrew Bozzi
 * Riot Games Code Sample
 * 5/10/10
 */

//**This is the new achievement that is to be uses the new statistic statistic Buildings Destroyed and 
//**the statistic Kills
//This is an example of a two stat achievement. There is an extra stat variable and an extra target value
//as well as the boolean doubleStat being set to true
public class Award_WreckingBall extends Achievement{
	public Award_WreckingBall(){
		this.description = "A user receives this for killing 8 or more opponents and destroying 3 or more buildings in a single game.";
		this.name = "Wrecking Ball";
		this.stat = new Statistic_Kills();
		this.stat2 = new Statistic_BuildingsDestroyed();
		this.targetValue = 8;
		this.targetValue2 = 3;
		//set double stat to true so that the checker in player knows to check for 2 statistics.
		this.doubleStat = true;
	}
	
	//override the default method since it is a double stat that needs a special set of logic
	@Override
	public boolean checkIfEarned(Statistic stat, Statistic stat2) {
		if((stat.getStatisticValue() >= targetValue) && (stat2.getStatisticValue() >= targetValue2)){
			return true;
		}
		return false;
	}
}
