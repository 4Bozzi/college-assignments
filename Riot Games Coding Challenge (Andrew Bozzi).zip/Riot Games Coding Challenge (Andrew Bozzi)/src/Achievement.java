/**
 * @author Andrew Bozzi
 * Riot Games Code Sample
 * 5/10/10
 */

//I decided to make the Achievement class abstract so that when it is time to create a new achievement
//all one has to do is create a new class extend achievement and all of the methods and fields implemented 
//here will be usable. If any function needs to be changed it can be overridden with a new implementation.
/**
 * The Achievement object includes a name, description, one or two statistics and their target values so that 
 * the achievement knows when to be awarded. It also has a boolean called doubleStat that is set to true if it
 * the particular award uses two statistics.
 */
abstract class Achievement {
	protected String description;
	protected String name;
	protected Statistic stat;
	protected Statistic stat2;
	protected int targetValue;
	protected int targetValue2;
	protected Boolean doubleStat;
	
	//default constructor sets doubleStat to false since that is the most common type of Achievement. This
	//can be set later for a double stat achievement. The other fields are different for each achievement.
	public Achievement(){
		doubleStat = false;
	}

	public String getDescription() {
		return description;
	}

	public String getName() {
		return name;
	}

	public Statistic getStat() {
		return stat;
	}
	
	public Statistic getStat2() {
		if(doubleStat){
			return stat2;
		}
		return null;
	}
	
	public boolean isDoubleStat() {
		return doubleStat;
	}
	
	//TheckIfEarned is the method that notifies a player if they get an achievement, this is the default
	//check but for different types of achievements it can be changed to reflect the goal of the award.
	//It uses the statistic to check if its value is satisfactory for the target value.
	public boolean checkIfEarned(Statistic stat) {
		if(stat.getStatisticValue()>=targetValue){
			return true;
		}
		return false;
	}
	
	//This is the two statistic version of checkIfEarned, default returns false this can be redefined later
	public boolean checkIfEarned(Statistic stat, Statistic stat2) {
		return false;
	}
}
