/**
 * @author Andrew Bozzi
 * Riot Games Code Sample
 * 5/10/10
 */

//Set the ID and the name, for the convenience of testing a second constructor was created that
//takes a value as an argument so that each statistic can be easily initialized.
public class Statistic_Assists extends Statistic{
	public Statistic_Assists() {
		statisticID = 0;
		statisticName = "Number of Assists";
	}
	
	public Statistic_Assists(int value) {
		statisticID = 0;
		statisticName = "Number of Assists";
		this.statisticValue = value;
	}
}
