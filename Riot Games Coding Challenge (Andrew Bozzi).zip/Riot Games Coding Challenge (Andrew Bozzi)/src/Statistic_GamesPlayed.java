/**
 * @author Andrew Bozzi
 * Riot Games Code Sample
 * 5/10/10
 */

//Set the ID and the name, for the convenience of testing a second constructor was created that
//takes a value as an argument so that each statistic can be easily initialized.
public class Statistic_GamesPlayed extends Statistic{
	public Statistic_GamesPlayed() {
		statisticID = 10;
		statisticName = "Games Played";
	}
	
	public Statistic_GamesPlayed(int value) {
		statisticID = 10;
		statisticName = "Games Played";
		this.statisticValue = value;
	}
}
