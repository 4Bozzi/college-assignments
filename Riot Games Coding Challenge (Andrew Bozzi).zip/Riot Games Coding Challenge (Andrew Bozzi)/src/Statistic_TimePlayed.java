/**
 * @author Andrew Bozzi
 * Riot Games Code Sample
 * 5/10/10
 */

//Set the ID and the name, for the convenience of testing a second constructor was created that
//takes a value as an argument so that each statistic can be easily initialized.
public class Statistic_TimePlayed extends Statistic{
	public Statistic_TimePlayed() {
		statisticID = 7;
		statisticName = "Amount of Time Played";
	}
	
	public Statistic_TimePlayed(int value) {
		statisticID = 7;
		statisticName = "Amount of Time Played";
		this.statisticValue = value;
	}
}
