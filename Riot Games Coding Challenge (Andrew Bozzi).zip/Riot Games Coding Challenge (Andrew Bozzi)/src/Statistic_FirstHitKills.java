/**
 * @author Andrew Bozzi
 * Riot Games Code Sample
 * 5/10/10
 */

//Set the ID and the name, for the convenience of testing a second constructor was created that
//takes a value as an argument so that each statistic can be easily initialized.
public class Statistic_FirstHitKills extends Statistic{
	public Statistic_FirstHitKills() {
		statisticID = 1;
		statisticName = "Number of First Hit Kills";
	}
	
	public Statistic_FirstHitKills(int value) {
		statisticID = 1;
		statisticName = "Number of First Hit Kills";
		this.statisticValue = value;
	}
}
