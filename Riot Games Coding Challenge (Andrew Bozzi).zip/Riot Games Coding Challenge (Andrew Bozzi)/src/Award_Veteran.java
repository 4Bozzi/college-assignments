/**
 * @author Andrew Bozzi
 * Riot Games Code Sample
 * 5/10/10
 */

//This achievement uses the default checkIfEarned method from achievement.
public class Award_Veteran extends Achievement{
	public Award_Veteran(){
		this.description = "A user receives this achievement for playing 1000 games in their lifetime.";
		this.name = "Veteran";
		this.stat = new Statistic_GamesPlayed();
		this.targetValue = 1000;
	}
}
