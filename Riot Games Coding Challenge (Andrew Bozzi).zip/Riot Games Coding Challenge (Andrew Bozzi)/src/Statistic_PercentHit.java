/**
 * @author Andrew Bozzi
 * Riot Games Code Sample
 * 5/10/10
 */

//Set the ID and the name, for the convenience of testing a second constructor was created that
//takes a value as an argument so that each statistic can be easily initialized.
public class Statistic_PercentHit extends Statistic {
	public Statistic_PercentHit() {
		statisticID = 11;
		statisticName = "Percentage of Hits";
	}
	
	public Statistic_PercentHit(int value) {
		statisticID = 11;
		statisticName = "Percentage of Hits";
		this.statisticValue = value;
	}
}
