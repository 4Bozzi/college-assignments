/**
 * @author Andrew Bozzi
 * Riot Games Code Sample
 * 5/10/10
 */

//I made the Statistic class abstract so that all that needs to be done to create a new statistic
//is create a new class that extends statistic, and set the value of statisticName, statisticValue
//and statisticID and the statistic is done. The value of each statistic starts out 0. The ID is
//used in the statistic hash map that the Player class has so that the correct statistic and be
//used in all circumstances.
abstract class Statistic {
	protected String statisticName;
	protected int statisticValue;
	protected int statisticID;
	
	public Statistic(){
		statisticValue = 0;
	}
	
	
	public int getStatisticValue(){
		return statisticValue;
	}
	
	public String getStatisticName(){
		return statisticName;
	}
	
	public int getStatisticID(){
		return statisticID;
	}
	
	public void setStatisticValue(int newValue){
		statisticValue = newValue;
	}
	
	public void setStatisticName(String name){
		statisticName = name;
	}
}

