/**
 * @author Andrew Bozzi
 * Riot Games Code Sample
 * 5/10/10
 */

//This achievement uses the default checkIfEarned method from achievement.
public class Award_SharpShooter extends Achievement{
	public Award_SharpShooter(){
		this.description = "A user receives this for landing 75% of their attacks, assuming they have at least attacked once.";
		this.name = "Sharp Shooter";
		this.stat = new Statistic_PercentHit();
		this.targetValue = 75;
	}
}
