/**
 * @author Andrew Bozzi
 * Riot Games Code Sample
 * 5/10/10
 */
//**This is the new statistic that is to be used in conjunction with another statistic in the new
//**Wrecking Ball achievement
//Set the ID and the name, for the convenience of testing a second constructor was created that
//takes a value as an argument so that each statistic can be easily initialized.
public class Statistic_BuildingsDestroyed extends Statistic {
	public Statistic_BuildingsDestroyed() {
		statisticID = 12;
		statisticName = "Number of Buildings Destroyed";
	}
	
	public Statistic_BuildingsDestroyed(int value) {
		statisticID = 12;
		statisticName = "Number of Buildings Destroyed";
		this.statisticValue = value;
	}
}
