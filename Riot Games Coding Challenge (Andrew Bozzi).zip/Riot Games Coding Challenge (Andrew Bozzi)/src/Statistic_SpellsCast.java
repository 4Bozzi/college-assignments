/**
 * @author Andrew Bozzi
 * Riot Games Code Sample
 * 5/10/10
 */

//Set the ID and the name, for the convenience of testing a second constructor was created that
//takes a value as an argument so that each statistic can be easily initialized.
public class Statistic_SpellsCast extends Statistic{
	public Statistic_SpellsCast() {
		statisticID = 6;
		statisticName = "Number of Spells Cast";
	}
	
	public Statistic_SpellsCast(int value) {
		statisticID = 6;
		statisticName = "Number of Spells Cast";
		this.statisticValue = value;
	}
}
