import java.util.ArrayList;
import java.util.HashMap;

//Player represents the state of a player at the end of a game. They have a name, a set of statistics with values
//and a set of earned and unearned achievements. I chose to use a hash map for the statistics so that I could
//get the statistic by using the ID as the key. This was used to ensure that the correct statistic was being
//checked.
public class Player {
	protected HashMap<Integer, Statistic> playerStatistics;
	protected ArrayList<Achievement> earnedAchievements;
	protected ArrayList<Achievement> unearnedAchievements;
	protected String name;

	public Player(String name) {
		playerStatistics = new HashMap<Integer, Statistic>();
		earnedAchievements = new ArrayList<Achievement>();
		unearnedAchievements = new ArrayList<Achievement>();
		this.name = name;
	}

	public String getName() {
		return name;
	}
	
	public HashMap<Integer, Statistic> getStatsList() {
		return playerStatistics;
	}

	public ArrayList<Achievement> getAchievementsList() {
		return unearnedAchievements;
	}

	public ArrayList<Achievement> getEarnedAchievementsList() {
		return earnedAchievements;
	}
	
	//checkForNewAchievements iterates through the list of unearned achievements and checks to see if
	//any of them were earned. It calls the checkIfEarned method from each achievement and checks
	//it with the stat or stats from the players set of stats, that are associated with each achievement.
	//If the achievements was earned it prints to console who earned it and removes it from the unearned list
	//and puts it in the earned list
	public void checkForNewAchievements() {
		for(int i = 0; i < unearnedAchievements.size(); i++){
			//for a double statistic achievement
			if (unearnedAchievements.get(i).isDoubleStat()) {
				if(unearnedAchievements.get(i).checkIfEarned(playerStatistics.get(unearnedAchievements.get(i).getStat().getStatisticID()), playerStatistics.get(unearnedAchievements.get(i).getStat2().getStatisticID()))){
					System.out.println(this.getName() + " has earned the achievement " + unearnedAchievements.get(i).getName() + "!");
					earnedAchievements.add(unearnedAchievements.remove(i));
				}
			} else {
				//for a single statistic achievement
				if(unearnedAchievements.get(i).checkIfEarned(playerStatistics.get(unearnedAchievements.get(i).getStat().getStatisticID()))){
					System.out.println(this.getName() + " has earned the achievement " + unearnedAchievements.get(i).getName() + "!");
					earnedAchievements.add(unearnedAchievements.remove(i));
				}
			}
		}
	}
}
