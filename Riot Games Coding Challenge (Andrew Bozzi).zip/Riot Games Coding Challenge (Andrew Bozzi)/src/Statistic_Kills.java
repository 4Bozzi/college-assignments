/**
 * @author Andrew Bozzi
 * Riot Games Code Sample
 * 5/10/10
 */

//Set the ID and the name, for the convenience of testing a second constructor was created that
//takes a value as an argument so that each statistic can be easily initialized.
public class Statistic_Kills extends Statistic{
	public Statistic_Kills() {
		statisticID = 3;
		statisticName = "Number of Kills";
	}
	
	public Statistic_Kills(int value) {
		statisticID = 3;
		statisticName = "Number of Kills";
		this.statisticValue = value;
	}
}
