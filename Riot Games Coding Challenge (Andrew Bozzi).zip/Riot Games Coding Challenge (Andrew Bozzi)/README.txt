Andrew Bozzi
Riot Games Code Sample
5/10/10

The Game class is a jUnit test that initializes the data and runs the tests on it.
The Achievements and Statistics were designed so that if you want to create a new 
one, you just need to create a new class that extends either Achievement or Statistic.
If the Achievement or Statistic is different then the default, override any methods 
that don't do the right thing.

The new statistic that I created was buildings destroyed, to go along with the new
achievement "Wrecking Ball".